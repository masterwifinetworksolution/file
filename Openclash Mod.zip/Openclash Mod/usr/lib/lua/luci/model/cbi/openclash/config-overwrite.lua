local NXFS = require "nixio.fs"
local SYS  = require "luci.sys"
local HTTP = require "luci.http"
local DISP = require "luci.dispatcher"
local UTIL = require "luci.util"
local fs = require "luci.openclash"
local uci = require "luci.model.uci".cursor()
local json = require "luci.jsonc"
local datatype = require "luci.cbi.datatypes"

font_green = [[<b style=color:teal>]]
font_red = [[<b style=color:darkred>]]
font_off = [[</b>]]
bold_on  = [[<strong>]]
bold_off = [[</strong>]]

local op_mode = string.sub(luci.sys.exec('uci get openclash.config.operation_mode 2>/dev/null'),0,-2)
if not op_mode then op_mode = "redir-host" end
local lan_ip = SYS.exec("uci -q get network.lan.ipaddr |awk -F '/' '{print $1}' 2>/dev/null |tr -d '\n' || ip address show $(uci -q -p /tmp/state get network.lan.ifname || uci -q -p /tmp/state get network.lan.device) | grep -w 'inet'  2>/dev/null |grep -Eo 'inet [0-9\.]+' | awk '{print $2}' | tr -d '\n' || ip addr show 2>/dev/null | grep -w 'inet' | grep 'global' | grep 'brd' | grep -Eo 'inet [0-9\.]+' | awk '{print $2}' | head -n 1 | tr -d '\n'")

m = Map("openclash", translate("Timpa Pengaturan"))
m.pageaction = false
m.description = translate("Catatan: Untuk mengembalikan konfigurasi default, coba akses:").." <a href='javascript:void(0)' onclick='javascript:restore_config(this)'>http://"..lan_ip.."/cgi-bin/luci/admin/services/openclash/restore</a>"

s = m:section(TypedSection, "openclash")
s.anonymous = true

s:tab("settings", translate("Pengaturan Umum"))
s:tab("dns", "DNS "..translate("Pengaturan"))
s:tab("meta", translate("Pengaturan Meta"))
s:tab("rules", translate("Pengaturan Rule"))
s:tab("developer", translate("Pengaturan Pengembang"))

----- General Settings
o = s:taboption("settings", ListValue, "interface_name", translate("Mengikat Jaringan Interface"))
local de_int = SYS.exec("ip route |grep 'default' |awk '{print $5}' 2>/dev/null") or SYS.exec("/usr/share/openclash/openclash_get_network.lua 'dhcp'")
o.description = translate("Nama Bawaan Interface:").." "..font_green..bold_on..de_int..bold_off..font_off..translate(",Coba Aktifkan Jika Jaringan Loopback")
local interfaces = SYS.exec("ls -l /sys/class/net/ 2>/dev/null |awk '{print $9}' 2>/dev/null")
for interface in string.gmatch(interfaces, "%S+") do
   o:value(interface)
end
o:value("0", translate("Matikan"))
o.default = "0"

o = s:taboption("settings", Value, "tolerance", translate("Toleransi Grup Uji-URL").."(ms)")
o.description = translate("Beralih Ke Proksi Baru Saat Perbedaan Penundaan Antara Lama dan Tercepat Saat Ini Lebih Besar Dari Nilai Ini")
o:value("0", translate("Matikan"))
o:value("99")
o:value("123")
o.datatype = "uinteger"
o.default = "0"

o = s:taboption("settings", Value, "urltest_interval_mod", translate("Modifikasi Interval Pengujian URL").."(s)")
o.description = translate("Ubah Interval Uji-URL Di Konfigurasi")
o:value("0", translate("Matikan"))
o:value("99")
o:value("150")
o.datatype = "uinteger"
o.default = "0"

o = s:taboption("settings", Value, "urltest_address_mod", translate("Modifikasi Alamat Tes URL"))
o.description = translate("Ubah Alamat URL-Test Di Config")
o:value("0", translate("Matikan"))
o:value("http://www.gstatic.com/generate_204")
o:value("http://cp.cloudflare.com/generate_204")
o:value("https://cp.cloudflare.com/generate_204")
o:value("http://captive.apple.com/generate_204")
o.default = "0"

o = s:taboption("settings", Value, "github_address_mod", translate("Modifikasi Alamat Github"))
o.description = translate("Ubah Alamat Github Di Config Dan OpenClash Dengan Proxy (CDN) Untuk Mencegah Gagal Mengunduh File. Referensi Format:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"https://ghproxy.com/\")'>ghproxy.com</a>"
o:value("0", translate("Matikan"))
o:value("https://fastly.jsdelivr.net/")
o:value("https://testingcf.jsdelivr.net/")
o:value("https://raw.fastgit.org/")
o:value("https://cdn.jsdelivr.net/")
o.default = "0"

o = s:taboption("settings", ListValue, "log_level", translate("Tingkat Catatan"))
o.description = translate("Pilih Level Log Inti")
o:value("0", translate("Matikan"))
o:value("info", translate("Info"))
o:value("warning", translate("peringatan"))
o:value("error", translate("kesalahan"))
o:value("debug", translate("Debug"))
o:value("silent", translate("Diam"))
o.default = "0"

o = s:taboption("settings", Value, "dns_port")
o.title = translate("Port DNS")
o.default = "7874"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

o = s:taboption("settings", Value, "proxy_port")
o.title = translate("Port Redir")
o.default = "7892"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

o = s:taboption("settings", Value, "tproxy_port")
o.title = translate("Port TProxy")
o.default = "7895"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

o = s:taboption("settings", Value, "http_port")
o.title = translate("Port HTTP(S)")
o.default = "7890"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

o = s:taboption("settings", Value, "socks_port")
o.title = translate("Port SOCKS5")
o.default = "7891"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

o = s:taboption("settings", Value, "mixed_port")
o.title = translate("Port Campuran")
o.default = "7893"
o.datatype = "port"
o.rmempty = false
o.description = translate("Pastikan Port Tersedia")

---- DNS Settings

o = s:taboption("dns", Flag, "enable_custom_dns", font_red..bold_on..translate("Pengaturan DNS Kustom")..bold_off..font_off)
o.description = font_red..bold_on..translate("Atur OpenClash Upstream DNS Resolve Server")..bold_off..font_off
o.default = 0

o = s:taboption("dns", Flag, "append_wan_dns", translate("Tambahkan DNS Hulu"))
o.description = translate("Tambahkan DNS yang Ditugaskan Hulu dan IP Gateway ke Server Nama")
o.default = 1

o = s:taboption("dns", Flag, "append_default_dns", translate("Tambahkan DNS Bawaan"))
o.description = translate("Secara otomatis Menambahkan DNS yang Sesuai ke nameserver bawaan")
o.default = 1

if op_mode == "fake-ip" then
o = s:taboption("dns", Value, "fakeip_range", translate("Rentang IP Palsu (IPv4 Cidr)"))
o.description = translate("Tetapkan Rentang IP Palsu (IPv4 Cidr)")
o:value("0", translate("Matikan"))
o:value("198.18.0.1/16")
o.default = "0"
o.placeholder = "198.18.0.1/16"
function o.validate(self, value)
	if value == "0" then
		return "0"
	end
	if datatype.cidr4(value) then
		return value
	end
	return "198.18.0.1/16"
end

o = s:taboption("dns", Flag, "store_fakeip", translate("Kegigihan Palsu-IP"))
o.description = font_red..bold_on..translate("Cache Rekaman Resolusi DNS Fake-IP Ke File, Tingkatkan Kecepatan Respons Setelah Memulai")..bold_off..font_off
o.default = 1

end

o = s:taboption("dns", Flag, "custom_fallback_filter", translate("Fallback-Filter"))
o.description = translate("Terapkan Jika Fallback DNS Ditetapkan, Cegah Polusi DNS")
o.default = 0

custom_fallback_filter = s:taboption("dns", Value, "custom_fallback_fil")
custom_fallback_filter.template = "cbi/tvalue"
custom_fallback_filter.rows = 20
custom_fallback_filter.wrap = "off"
custom_fallback_filter:depends("custom_fallback_filter", "1")

function custom_fallback_filter.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_fallback_filter.yaml") or ""
end
function custom_fallback_filter.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_fallback_filter.yaml")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_fallback_filter.yaml", value)
		end
	end
end

if op_mode == "fake-ip" then
o = s:taboption("dns", Flag, "custom_fakeip_filter", translate("Fake-IP-Filter"))
o.default = 0

custom_fake_black = s:taboption("dns", Value, "custom_fake_filter")
custom_fake_black.template = "cbi/tvalue"
custom_fake_black.description = translate("Domain Names In The List Do Not Return Fake-IP, One rule per line")
custom_fake_black.rows = 20
custom_fake_black.wrap = "off"
custom_fake_black:depends("custom_fakeip_filter", "1")

function custom_fake_black.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_fake_filter.list") or ""
end
function custom_fake_black.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_fake_filter.list")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_fake_filter.list", value)
		end
	end
end
end

o = s:taboption("dns", Flag, "custom_name_policy", translate("Nameserver-Policy"))
o.default = 0

custom_domain_dns_policy = s:taboption("dns", Value, "custom_domain_dns_core")
custom_domain_dns_policy.template = "cbi/tvalue"
custom_domain_dns_policy.description = translate("Domain Names In The List Use The Custom DNS Server, But Still Return Fake-IP Results, One rule per line")
custom_domain_dns_policy.rows = 20
custom_domain_dns_policy.wrap = "off"
custom_domain_dns_policy:depends("custom_name_policy", "1")

function custom_domain_dns_policy.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_domain_dns_policy.list") or ""
end
function custom_domain_dns_policy.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_domain_dns_policy.list")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_domain_dns_policy.list", value)
		end
	end
end

o = s:taboption("dns", Flag, "custom_host", translate("Hosts"))
o.default = 0

custom_hosts = s:taboption("dns", Value, "custom_hosts")
custom_hosts.template = "cbi/tvalue"
custom_hosts.description = translate("Host Kustom Di Sini, Anda Mungkin Perlu Mematikan Opsi Perlindungan Rebinding dari Dnsmasq Ketika Host Telah Menetapkan Alamat yang Dicadangkan, Untuk Lebih Lanjut Buka:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"https://lancellc.gitbook.io/clash/clash-config-file/dns/host\")'>https://lancellc.gitbook.io/clash/clash-config-file/dns/host</a>"
custom_hosts.rows = 20
custom_hosts.wrap = "off"
custom_hosts:depends("custom_host", "1")

function custom_hosts.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_hosts.list") or ""
end
function custom_hosts.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_hosts.list")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_hosts.list", value)
		end
	end
end

-- Meta
o = s:taboption("meta", Flag, "enable_tcp_concurrent", font_red..bold_on..translate("Aktifkan Tcp Bersamaan")..bold_off..font_off)
o.description = font_red..bold_on..translate("IP Permintaan Bersamaan TCP, Pilih Satu Latensi Terendah Untuk Koneksi")..bold_off..font_off
o.default = "0"

o = s:taboption("meta", ListValue, "find_process_mode", translate("Aktifkan Proses Rule"))
o.description = translate("Apakah akan Mengaktifkan Aturan Proses, Jika Anda Tidak Yakin, Silakan Pilih Yang Berguna di Lingkungan Router")
o:value("0", translate("Matikan"))
o:value("off", translate("Mati　"))
o:value("always", translate("Selalu　"))
o:value("strict", translate("Ketat　"))
o.default = "0"

o = s:taboption("meta", ListValue, "global_client_fingerprint", translate("Sidik Jari Klien"))
o.description = translate("Ubah Sidik Jari Klien, Hanya Mendukung Transportasi TLS di TCP/GRPC/WS/HTTP Untuk Vless/Vmess dan Trojan")
o:value("0", translate("Matikan"))
o:value("none", translate("Kosong　"))
o:value("random", translate("Acak"))
o:value("chrome", translate("Chrome"))
o:value("firefox", translate("Firefox"))
o:value("safari", translate("Safari"))
o:value("ios", translate("IOS"))
o:value("android", translate("Android"))
o:value("edge", translate("Edge"))
o:value("360", translate("360"))
o:value("qq", translate("QQ"))
o.default = "0"

o = s:taboption("meta", ListValue, "geodata_loader", translate("Pemuat Geodata"))
o:value("0", translate("Matikan"))
o:value("memconservative", translate("Memkonservatif"))
o:value("standard", translate("Bawaan"))
o.default = "0"

o = s:taboption("meta", ListValue, "enable_geoip_dat", translate("Aktifkan Data GeoIP"))
o.description = translate("Ganti GEOIP MMDB Dengan GEOIP Dat, File Ukuran Besar")..", "..font_red..bold_on..translate("Perlu Unduh Dulu")..bold_off..font_off
o.default = 0
o:value("0", translate("Matikan"))
o:value("1", translate("Hidupkan"))

o = s:taboption("meta", Flag, "enable_meta_sniffer", font_red..bold_on..translate("Aktifkan Sniffer")..bold_off..font_off)
o.description = font_red..bold_on..translate("Sniffer Akan Mencegah Proxy Nama Domain dan Kegagalan Pembajakan DNS")..bold_off..font_off
o.default = 1

o = s:taboption("meta", Flag, "enable_meta_sniffer_pure_ip", translate("Paksa Sniff Pure IP"))
o.description = translate("Koneksi IP Pure Sniff Paksa")
o.default = 1
o:depends("enable_meta_sniffer", "1")

o = s:taboption("meta", Flag, "enable_meta_sniffer_custom", translate("Pengaturan Sniffer Kustom"))
o.description = translate("Kustomisasi The Force dan Skip Sniffing Domain Lists")
o.default = 0
o:depends("enable_meta_sniffer", "1")

sniffing_domain_force = s:taboption("meta", Value, "sniffing_domain_force")
sniffing_domain_force:depends("enable_meta_sniffer_custom", "1")
sniffing_domain_force.template = "cbi/tvalue"
sniffing_domain_force.description = translate("Akan Mengesampingkan Permintaan Dns Jika Domain dalam Daftar")
sniffing_domain_force.rows = 20
sniffing_domain_force.wrap = "off"

function sniffing_domain_force.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_force_sniffing_domain.yaml") or ""
end
function sniffing_domain_force.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_force_sniffing_domain.yaml")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_force_sniffing_domain.yaml", value)
		end
	end
end

sniffing_port_filter = s:taboption("meta", Value, "sniffing_port_filter")
sniffing_port_filter:depends("enable_meta_sniffer_custom", "1")
sniffing_port_filter.template = "cbi/tvalue"
sniffing_port_filter.description = translate("Hanya Akan Mengendus Jika Port Di Daftar")
sniffing_port_filter.rows = 20
sniffing_port_filter.wrap = "off"

function sniffing_port_filter.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_sniffing_ports_filter.yaml") or ""
end
function sniffing_port_filter.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_sniffing_ports_filter.yaml")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_sniffing_ports_filter.yaml", value)
		end
	end
end

sniffing_domain_filter = s:taboption("meta", Value, "sniffing_domain_filter")
sniffing_domain_filter:depends("enable_meta_sniffer_custom", "1")
sniffing_domain_filter.template = "cbi/tvalue"
sniffing_domain_filter.description = translate("Akan Nonaktifkan Sniffing Jika Domain (sni) dalam Daftar")
sniffing_domain_filter.rows = 20
sniffing_domain_filter.wrap = "off"

function sniffing_domain_filter.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_sniffing_domain_filter.yaml") or ""
end
function sniffing_domain_filter.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_sniffing_domain_filter.yaml")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_sniffing_domain_filter.yaml", value)
		end
	end
end

---- Rules Settings
o = s:taboption("rules", Flag, "rule_source", translate("Aktifkan Aturan Lain"))
o.description = translate("Gunakan Aturan Lain")
o.default = 0

o = s:taboption("rules", Flag, "enable_rule_proxy", translate("Mode Proksi Pencocokan Aturan"))
o.description = translate("Tambahkan Beberapa Aturan ke Konfigurasi, Izinkan Hanya Proksi Lalu Lintas yang Cocok dengan Aturan, Cegah BT/P2P Passing")
o.default = 0

o = s:taboption("rules", Flag, "enable_custom_clash_rules", font_red..bold_on..translate("Aturan Kustom Clash")..bold_off..font_off)
o.description = translate("Gunakan Aturan Khusus")
o.default = 0

custom_rules = s:taboption("rules", Value, "custom_rules")
custom_rules:depends("enable_custom_clash_rules", 1)
custom_rules.template = "cbi/tvalue"
custom_rules.description = translate("Aturan Prioritas Khusus Di Sini, Untuk Lebih Lanjut:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"https://lancellc.gitbook.io/clash/clash-config-file/rules\")'>https://lancellc.gitbook.io/clash/clash-config-file/rules</a>".." ,"..translate("IP ke CIDR:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"http://ip2cidr.com\")'>http://ip2cidr.com</a>"
custom_rules.rows = 20
custom_rules.wrap = "off"

function custom_rules.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_rules.list") or ""
end
function custom_rules.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_rules.list")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_rules.list", value)
		end
	end
end

custom_rules_2 = s:taboption("rules", Value, "custom_rules_2")
custom_rules_2:depends("enable_custom_clash_rules", 1)
custom_rules_2.template = "cbi/tvalue"
custom_rules_2.description = translate("Aturan Perpanjangan Kustom Di Sini, Untuk Lebih Lanjut:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"https://lancellc.gitbook.io/clash/clash-config-file/rules\")'>https://lancellc.gitbook.io/clash/clash-config-file/rules</a>".." ,"..translate("IP ke CIDR:").." ".."<a href='javascript:void(0)' onclick='javascript:return winOpen(\"http://ip2cidr.com\")'>http://ip2cidr.com</a>"
custom_rules_2.rows = 20
custom_rules_2.wrap = "off"

function custom_rules_2.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_rules_2.list") or ""
end
function custom_rules_2.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_rules_2.list")
	  if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_rules_2.list", value)
		end
	end
end

---- developer
o = s:taboption("developer", Value, "ymchange_custom")
o.template = "cbi/tvalue"
o.description = translate("Script Timpa Config Kustom Yang Akan Berjalan Setelah Plugin Dimiliki Sepenuhnya, Harap Berhati-hati, Perubahan yang Salah Dapat Menyebabkan Pengecualian")
o.rows = 30
o.wrap = "off"

function o.cfgvalue(self, section)
	return NXFS.readfile("/etc/openclash/custom/openclash_custom_overwrite.sh") or ""
end
function o.write(self, section, value)
	if value then
		value = value:gsub("\r\n?", "\n")
		local old_value = NXFS.readfile("/etc/openclash/custom/openclash_custom_overwrite.sh")
		if value ~= old_value then
			NXFS.writefile("/etc/openclash/custom/openclash_custom_overwrite.sh", value)
		end
	end
end

-- [[ Edit Custom DNS ]] --
ds = m:section(TypedSection, "dns_servers", translate("Add Custom DNS Servers")..translate("(Terapkan Setelah Memilih Di Atas)"))
ds.anonymous = true
ds.addremove = true
ds.sortable = true
ds.template = "openclash/tblsection_dns"
ds.extedit = luci.dispatcher.build_url("admin/services/openclash/custom-dns-edit/%s")
function ds.create(...)
	local sid = TypedSection.create(...)
	if sid then
		luci.http.redirect(ds.extedit % sid)
		return
	end
end

---- enable flag
o = ds:option(Flag, "enabled", translate("Aktifkan"))
o.rmempty     = false
o.default     = o.enabled
o.cfgvalue    = function(...)
    return Flag.cfgvalue(...) or "1"
end

---- group
o = ds:option(ListValue, "group", translate("Grup DNS Server"))
o:value("nameserver", translate("Nama Server "))
o:value("fallback", translate("FallBack "))
o:value("default", translate("Bawaan Nama Server"))
o.default     = "nameserver"
o.rempty      = false

---- IP address
o = ds:option(Value, "ip", translate("Alamat Server DNS"))
o.placeholder = translate("bukan Kosong")
o.datatype = "or(host, string)"
o.rmempty = true

---- port
o = ds:option(Value, "port", translate("Port Server DNS"))
o.datatype    = "port"
o.rempty      = true

---- type
o = ds:option(ListValue, "type", translate("Type Server DNS"))
o:value("udp", translate("UDP"))
o:value("tcp", translate("TCP"))
o:value("tls", translate("TLS"))
o:value("https", translate("HTTPS"))
o:value("quic", translate("QUIC ")..translate("(Hanya Meta Core)"))
o.default     = "udp"
o.rempty      = false

-- [[ Other Rules Manage ]]--
ss = m:section(TypedSection, "other_rules", translate("Sunting Aturan Lainnya")..translate("(Terapkan Setelah Memilih Di Atas)"))
ss.anonymous = true
ss.addremove = true
ss.sortable = true
ss.template = "cbi/tblsection"
ss.extedit = luci.dispatcher.build_url("admin/services/openclash/other-rules-edit/%s")
function ss.create(...)
	local sid = TypedSection.create(...)
	if sid then
		luci.http.redirect(ss.extedit % sid)
		return
	end
end

o = ss:option(Flag, "enabled", translate("Aktifkan"))
o.rmempty     = false
o.default     = o.enabled
o.cfgvalue    = function(...)
    return Flag.cfgvalue(...) or "1"
end

o = ss:option(DummyValue, "config", translate("File Config"))
function o.cfgvalue(...)
	return Value.cfgvalue(...) or translate("Kosong")
end

o = ss:option(DummyValue, "rule_name", translate("Nama Aturan Lainnya"))
function o.cfgvalue(...)
	if Value.cfgvalue(...) == "lhie1" then
		return translate("Rule lhie1")
	elseif Value.cfgvalue(...) == "ConnersHua" then
		return translate("Rule ConnersHua (Type Provider)")
	elseif Value.cfgvalue(...) == "ConnersHua_return" then
		return translate("Kembali Rule ConnersHua")
	else
		return translate("Kosong")
	end
end

o = ss:option(DummyValue, "Note", translate("Catatan"))
function o.cfgvalue(...)
	return Value.cfgvalue(...) or translate("Kosong")
end

-- [[ Edit Authentication ]] --
s = m:section(TypedSection, "authentication", translate("Tetapkan Otentikasi SOCKS5/HTTP(S)"))
s.anonymous = true
s.addremove = true
s.sortable = false
s.template = "cbi/tblsection"
s.rmempty = false

---- enable flag
o = s:option(Flag, "enabled", translate("Aktifkan"))
o.rmempty     = false
o.default     = o.enabled
o.cfgvalue    = function(...)
    return Flag.cfgvalue(...) or "1"
end

---- username
o = s:option(Value, "username", translate("Nama Pengguna"))
o.placeholder = translate("Kosong")
o.rempty      = true

---- password
o = s:option(Value, "password", translate("Sandi"))
o.placeholder = translate("Kosong")
o.rmempty = true

local t = {
    {Commit, Apply}
}

a = m:section(Table, t)

o = a:option(Button, "Commit", " ")
o.inputtitle = translate("Simpan Pengaturan")
o.inputstyle = "apply"
o.write = function()
  m.uci:commit("openclash")
end

o = a:option(Button, "Apply", " ")
o.inputtitle = translate("Setujui Pengaturan")
o.inputstyle = "apply"
o.write = function()
  m.uci:set("openclash", "config", "enable", 1)
  m.uci:commit("openclash")
  SYS.call("/etc/init.d/openclash restart >/dev/null 2>&1 &")
  HTTP.redirect(DISP.build_url("admin", "services", "openclash"))
end

m:append(Template("openclash/config_editor"))
m:append(Template("openclash/toolbar_show"))

return m


